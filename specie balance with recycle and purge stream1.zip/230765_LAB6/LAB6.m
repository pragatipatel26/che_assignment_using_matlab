%overall balance
%Balance on C:
%n1=molar flow rate of F1 stream
n1=50*3/3;

%Balance on H:
%n7=molar flow rate of F4 stream
n7=(8*n1-6*50)/2;

%molar flow rate of n4(F3) stream
n4=n7;

%molar flow rate of n2(F2) stream
n2=n4/0.4;

%molar flow rate of n5(F3) stream
n5=0.6*n2;

%molar flow rate of n8(F6) stream
n8=(n2-n1)/0.8;

%molar flow rate of n3(F2) stream
n3=0.2*n8;

%molar flow rate of n6(F3) stream
n6=n3+0.4*n2;

disp(n1)
disp(n2)
disp(n3)
disp(n4)
disp(n5)
disp(n6)
disp(n7)
disp(n8)