%P=101.325
temperature = 'What is the temperature value? ';
T = input(temperature)
x=linspace(0,1,11);
n=length(x);
P=zeros(n,1);
y=zeros(n,1);
for i=1:n
   P(i)=(exp(13.7819-2726.81/(T+217.572)))*x(i)+(exp(13.9320-3056.96/(T+217.625)))*(1-x(i));
end
for i=1:n
    y(i)=((exp(13.7819-2726.81/(T+217.572)))/P(i))*x(i);
end
disp(P)
disp(x)
disp(y)
figure
plot(x,P)
xlabel('x1 and y1')
ylabel('Pressure')
hold on
plot(y,P)
hold off