%EXTENT OF REACTION1
E1=1-0.1*1;
disp(E1)
%EXTENT OF REACTON2
E2=E1-70/100;
disp(E2)
%% x=mol of air
x=(0.5/0.21)*2;
disp(x)
%moles of CH3OH
n1=1-E1;
disp(n1)
%mole of CH2O
n2=E1-E2;
disp(n2)
%mole of H2O
n3=E1+E2;
disp(n3)
%mole of CO
n4=E2;
disp(n4)
%mole of N2
n5=0.79*x;
disp(n5)
%mole of O2
n6=x*0.21-E1/2-E2/2;
disp(n6)