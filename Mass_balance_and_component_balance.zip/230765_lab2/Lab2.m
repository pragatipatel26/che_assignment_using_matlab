fun=@myfun;
x0=[0,0,0,0.001,0.001,0.001,0.001];
x=fsolve(fun,x0)