clc
clear all;

% part 1
Question_1 = fun(.8,1.5);
% Q2
Question_2 = fun(.98,1.5);
% Q3
Question_3 = fun(.98,1.2);
% Q4
Question_4 = fun(.98,1);
function stages = fun(recovery,factor)
et = [0 ;0.0186; 0.0476 ;0.0673 ;0.0881 ;0.1102 ;0.1424 ;0.1894 ;0.2069];
ET = et./(1-et);
wat = [0 ;0.0105 ;0.0272 ;0.0375 ;0.0492 ;0.0624 ;0.0809 ;0.1078 ;0.1182];
WAT = wat./(1-wat);
f = fit(ET,WAT,'poly1');
% disp(f)
% here slope is 0.5127 and intercept is very small so we will ignore it
alpha = .5127;
yin = .15;%in kg
xin = 0;
Xin = 0;
Gin = 2000;
% recovery = .80;
yout = yin*(1-recovery);
Yin = yin/(1-yin);
Gs = Gin*(1-Yin);
Yout = yout/(1-yout);
Gout = Gs/(1-Yout);
Lsmin = Gs*((Yin-Yout)/(Yin/alpha+Xin));
Ls = factor*Lsmin;
Lin = Ls;

M_op = Ls/Gs;
Xout = (Yin - Yout)/M_op;
Ynew = 1000;
Xnew = Xout;
count= 0;
while(abs(Ynew-Yout)>0.005)
 Ynew = alpha*Xnew;
 Xnew = (Ynew-Yin)/M_op + Xout;
 count = count +1;
 if(count>100)
 fprintf("Solution has infinite stages\n")
 break;
 end
end
stages = count;
if(stages<101)
 fprintf("Number of stages is %f for recovery %f\n",stages,recovery);
end
end