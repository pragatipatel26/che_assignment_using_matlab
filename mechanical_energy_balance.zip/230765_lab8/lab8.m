%Q=Win/(ρ*g*H)
P=1000;
g=9.81;
W=200;
H=linspace(1,100,101);
n=length(H);
Q=zeros(n,1);
for i=1:n
    Q(i)=W/(P*g*H(i));
end
plot(H,Q)
xlabel('H')
ylabel('Q')
